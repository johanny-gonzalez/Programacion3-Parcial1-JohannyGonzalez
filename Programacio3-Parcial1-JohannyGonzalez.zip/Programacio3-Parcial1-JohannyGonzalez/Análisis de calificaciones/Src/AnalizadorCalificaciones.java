public class AnalizadorCalificaciones {
    public static void main(String[] args) {
        
        int[] notas = {78, 92, 55, 88, 70, 95, 61};

        System.out.println("=== ANÁLISIS DE CALIFICACIONES ===");
        

        System.out.print("Calificaciones registradas: ");
        for (int i = 0; i < notas.length; i++) {
            System.out.print(notas[i] + (i < notas.length - 1 ? ", " : ""));
        }
        System.out.println();

        double suma = 0;
        int mayor = notas[0];
        int menor = notas[0];
        int aprobados = 0;

        for (int nota : notas) {
            suma += nota;
            if (nota > mayor) {
                mayor = nota;
            }
            if (nota < menor) {
                menor = nota;
            }
            if (nota >= 70) {
                aprobados++;
            }
        }

        double promedio = suma / notas.length;
        System.out.printf("Promedio general: %.2f\n", promedio);

        System.out.println("Nota más alta: " + mayor);
        System.out.println("Nota más baja: " + menor);

        System.out.println("Estudiantes aprobados: " + aprobados);
    }
}

