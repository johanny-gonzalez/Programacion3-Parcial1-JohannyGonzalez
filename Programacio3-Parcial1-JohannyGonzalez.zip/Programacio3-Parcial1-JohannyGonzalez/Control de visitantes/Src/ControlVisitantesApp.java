import java.util.ArrayList;
import java.util.Scanner;

class VisitanteInvalidoException extends Exception {
    public VisitanteInvalidoException(String mensaje) {
        super(mensaje);
    }
}

enum Estado {
    DENTRO, SALIO
}

class Visitante {
    private String nombre;
    private String cedula;
    private String motivo;
    private Estado estado;

    public Visitante(String nombre, String cedula, String motivo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.motivo = motivo;
        this.estado = Estado.DENTRO; 
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
}

public class ControlVisitantesApp {
    public static void main(String[] args) {
        ArrayList<Visitante> visitantes = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        do {
            System.out.println("\n===== CONTROL DE VISITANTES =====");
            System.out.println("1. Registrar entrada");
            System.out.println("2. Buscar por nombre");
            System.out.println("3. Listar visitantes");
            System.out.println("4. Registrar salida");
            System.out.println("5. Eliminar registro");
            System.out.println("6. Generar reporte");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
                continue;
            }

            switch (opcion) {
                case 1: 
                    try {
                        System.out.print("Ingrese nombre: ");
                        String nombre = scanner.nextLine().trim();
                        System.out.print("Ingrese cédula: ");
                        String cedula = scanner.nextLine().trim();
                        System.out.print("Ingrese motivo de visita: ");
                        String motivo = scanner.nextLine().trim();

                        if (nombre.isEmpty() || cedula.isEmpty() || motivo.isEmpty()) {
                            throw new VisitanteInvalidoException("Error: Ningún dato puede estar vacío.");
                        }

                        for (Visitante v : visitantes) {
                            if (v.getCedula().equalsIgnoreCase(cedula)) {
                                throw new VisitanteInvalidoException("Error: La cédula ingresada ya se encuentra registrada.");
                            }
                        }

                        visitantes.add(new Visitante(nombre, cedula, motivo));
                        System.out.println("¡Registro de entrada exitoso!");

                    } catch (VisitanteInvalidoException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 2: 
                    System.out.print("Ingrese nombre o parte del nombre a buscar: ");
                    String busqueda = scanner.nextLine().trim().toLowerCase();
                    boolean encontrado = false;

                    System.out.println("\n--- RESULTADOS DE BÚSQUEDA ---");
                    for (Visitante v : visitantes) {
                        if (v.getNombre().toLowerCase().contains(busqueda)) {
                            System.out.println("Nombre: " + v.getNombre() + " | Cédula: " + v.getCedula() + 
                                               " | Motivo: " + v.getMotivo() + " | Estado: " + v.getEstado());
                            encontrado = true;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("No se encontró ningún visitante con ese criterio.");
                    }
                    break;

                case 3: 
                    System.out.println("\n--- LISTA GENERAL DE VISITANTES ---");
                    if (visitantes.isEmpty()) {
                        System.out.println("No hay visitantes registrados actualmente.");
                    } else {
                        for (Visitante v : visitantes) {
                            System.out.println("Nombre: " + v.getNombre() + " | Cédula: " + v.getCedula() + 
                                               " | Motivo: " + v.getMotivo() + " | Estado: " + v.getEstado());
                        }
                    }
                    break;

                case 4:
                    System.out.print("Ingrese la cédula del visitante para registrar salida: ");
                    String cedulaSalida = scanner.nextLine().trim();
                    Visitante visitanteEncontrado = null;

                    for (Visitante v : visitantes) {
                        if (v.getCedula().equalsIgnoreCase(cedulaSalida)) {
                            visitanteEncontrado = v;
                            break;
                        }
                    }

                    if (visitanteEncontrado == null) {
                        System.out.println("Error: La cédula no existe en los registros.");
                    } else if (visitanteEncontrado.getEstado() == Estado.SALIO) {
                        System.out.println("Aviso: El visitante con cédula " + cedulaSalida + " ya había registrado su salida.");
                    } else {
                        visitanteEncontrado.setEstado(Estado.SALIO);
                        System.out.println("Salida registrada con éxito para " + visitanteEncontrado.getNombre());
                    }
                    break;

                case 5:
                    System.out.print("Ingrese la cédula del visitante a eliminar: ");
                    String cedulaEliminar = scanner.nextLine().trim();
                    boolean eliminado = false;

                    for (int i = 0; i < visitantes.size(); i++) {
                        if (visitantes.get(i).getCedula().equalsIgnoreCase(cedulaEliminar)) {
                            visitantes.remove(i);
                            eliminado = true;
                            System.out.println("Registro eliminado exitosamente.");
                            break;
                        }
                    }

                    if (!eliminado) {
                        System.out.println("No se encontró ningún visitante con esa cédula para eliminar.");
                    }
                    break;

                case 6:
                    Thread hiloReporte = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            int total = visitantes.size();
                            int dentro = 0;
                            int salio = 0;

                            for (Visitante v : visitantes) {
                                if (v.getEstado() == Estado.DENTRO) {
                                    dentro++;
                                } else {
                                    salio++;
                                }
                            }

                            System.out.println("\n-----------------------------------------");
                            System.out.println("          REPORTE DE VISITANTES          ");
                            System.out.println("-----------------------------------------");
                            System.out.println("Total de registros actuales : " + total);
                            System.out.println("Visitantes DENTRO           : " + dentro);
                            System.out.println("Visitantes que han SALIDO   : " + salio);
                            System.out.println("-----------------------------------------");
                        }
                    });

                    try {
                        hiloReporte.start();
                        hiloReporte.join(); 
                    } catch (InterruptedException e) {
                        System.out.println("El hilo del reporte fue interrumpido.");
                    }
                    break;

                case 7:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;

                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción del 1 al 7.");
            }
        } while (opcion != 7);

        scanner.close();
    }
}